package dilz.e32191672.infoku;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class MainActivity extends AppCompatActivity {
    WebView WebViewku;
    WebSettings WebSettingsku;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebViewku = (WebView) findViewById(R.id.WebView1);

        WebSettingsku = WebViewku.getSettings();

        WebViewku.setWebViewClient(new WebViewClient());
        WebViewku.loadUrl("http://jti.polije.ac.id/");


    }
}